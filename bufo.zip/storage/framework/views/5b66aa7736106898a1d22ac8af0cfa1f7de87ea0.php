
<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="card">
  <div class="card-header">
    <h4><?php echo e($post->post); ?></h4>
    <b>Post by: <?php echo e($post->users->name); ?></b>
  </div>

  <div class="card-body">
    <h5>Comments: </h5>
    <?php $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <b>
        <?php echo e($comment->user->get()[0]->name); ?>:
    </b>
    <p style="margin:0;padding:0;margin-left:20px;"><?php echo e($comment->comment); ?></p>
    <hr style="margin:2px"/>
    
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <form method="post" action="<?php echo e(route('store-comment')); ?>">
      <?php echo csrf_field(); ?>
      <input type="hidden" name="parent_id" value="<?php echo e($post->id); ?>"/>
      <div class="form-group">
        <textarea class="form-control" id="comment" name="comment" rows="1"></textarea>
      </div>
      <div class="form-group">
          <button style="width:100%" type="submit" class="btn btn-success mb-12">Post comment</button>
      </div>
    </form>
  </div>
                  
</div>
</br>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH /Users/ardiantutomo/Code/garudahacks/resources/views/posts.blade.php ENDPATH**/ ?>